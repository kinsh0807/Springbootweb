package com.masai.webapp.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootwebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootwebappApplication.class, args);
	}

}
